from django.contrib import admin
from .models import contactform
# Register your models here
@admin.register(contactform)
class review(admin.ModelAdmin):
    list_display=('name','email','subject','messages')
    
       