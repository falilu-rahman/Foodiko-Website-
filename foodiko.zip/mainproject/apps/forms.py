from django import forms
from .models import contactform

class Form(forms.ModelForm):
    class Meta:
        model = contactform
        fields =['name','email','subject','messages']