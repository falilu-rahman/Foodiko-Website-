from django.shortcuts import render,redirect
from .models import contactform
from .forms import Form
# Create your views here.
def home(request):
    return render(request,'index.html')

def about(request):
    return render(request, 'about.html')

def booking(request):
    return render(request, 'booking.html')




def menu(request):
    return render(request, 'menu.html')


def service(request):
    return render(request, 'service.html')


def team(request):
    return render(request, 'team.html')


def testimonial(request):
    return render(request, 'testimonial.html')

def contact(request):
    if request.method=='POST':
        form = Form(request.POST)
        if form.is_valid():
           form.save()         
        return render(request,"contact.html")
           
    return render(request,"contact.html")